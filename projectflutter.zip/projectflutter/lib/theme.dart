import 'package:flutter/material.dart';

Color primaryColor = Color(0xff314728);
Color greyColor = Color(0xffA9B0A6);
Color orangeColor = Color(0xffF9B650);
Color backgroundColor = Color(0xffE5E5E5);
Color whiteColor = Color(0xffFFFFFF);